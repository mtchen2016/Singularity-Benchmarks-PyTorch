Microsoft Azure CLI 'aisc' Extension


